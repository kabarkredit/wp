<?php

define('FIFU_SPEEDUP_SIZES', serialize(array(75, 100, 150, 240, 320, 500, 640, 800, 1024, 1280, 1600)));

function is_from_speedup($url) {
    return strpos($url, "featuredimagefromurl.com") !== false;
}

function fifu_resize_speedup_image_size($size, $url) {
    return strpos($url, 'original') !== false ? str_replace('original', $size, $url) : preg_replace("/[0-9]+[.]webp/", $size . '.webp', $url);
}

function fifu_speedup_get_set($url) {
    $width = (int) explode('-', $url)[1];
    $set = '';
    $count = 0;
    foreach (unserialize(FIFU_SPEEDUP_SIZES) as $i) {
        if ($width < $i) {
            $set .= ', ' . $url . ' ' . $i . 'w';
            break;
        }
        $set .= (($count++ != 0) ? ', ' : '') . fifu_resize_speedup_image_size($i, $url) . ' ' . $i . 'w';
        if ($width == $i)
            break;
    }
    return $set;
}

