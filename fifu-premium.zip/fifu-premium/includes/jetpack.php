<?php

define('FIFU_JETPACK_SIZES', serialize(array(75, 100, 150, 240, 320, 500, 640, 800, 1024, 1280, 1600)));

function is_from_jetpack($url) {
    return strpos($url, ".wp.com") !== false;
}

function fifu_resize_jetpack_image_size($size, $url) {
    return str_replace('?ssl=1', '?w=' . $size . '&resize=' . $size . '&ssl=1', $url);
}

function fifu_jetpack_get_set($url, $is_slider) {
    $quality = $is_slider ? 1.25 : 1;
    $set = '';
    $count = 0;
    foreach (unserialize(FIFU_JETPACK_SIZES) as $i)
        $set .= (($count++ != 0) ? ', ' : '') . fifu_resize_jetpack_image_size($i * $quality, $url) . ' ' . $i . 'w';
    return $set;
}

function fifu_debug_jetpack() {
    return defined('FIFU_DEV_DEBUG') && !defined('IS_WPCOM') && FIFU_DEV_DEBUG && fifu_is_local() && !fifu_is_in_editor();
}

