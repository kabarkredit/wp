<?php

define('FIFU_PLACEHOLDER', 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');

add_filter('wp_head', 'fifu_add_js');

if (!function_exists('is_plugin_active'))
    require_once(ABSPATH . '/wp-admin/includes/plugin.php');

global $pagenow;
if (!in_array($pagenow, array('post.php', 'post-new.php', 'admin-ajax.php', 'wp-cron.php'))) {
    if (is_plugin_active('wordpress-seo/wp-seo.php')) {
        add_action('wpseo_opengraph_image', 'fifu_add_social_tag_yoast');
        add_action('wpseo_twitter_image', 'fifu_add_social_tag_yoast');
        add_action('wpseo_add_opengraph_images', 'fifu_add_social_tag_yoast_list');
    } else
        add_filter('wp_head', 'fifu_add_social_tags');
    add_filter('wp_head', 'fifu_video_add_social_tags');
}

add_filter('wp_head', 'fifu_add_lightslider');
add_filter('wp_head', 'fifu_add_video');
add_filter('wp_head', 'fifu_add_shortcode');
add_filter('wp_head', 'fifu_apply_css');

function fifu_add_js() {
    echo '<link rel="preconnect" href="https://storage.googleapis.com">';
    echo '<link rel="preconnect" href="https://cdnjs.cloudflare.com">';

    if (fifu_is_on('fifu_lazy')) {
        wp_enqueue_style('lazyload-spinner', plugins_url('/html/css/lazyload.css', __FILE__), array(), fifu_version_number());
        wp_enqueue_script('lazysizes-config', plugins_url('/html/js/lazySizesConfig.js', __FILE__), array('jquery'), fifu_version_number());
        wp_enqueue_script('unveilhooks', 'https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.2.2/plugins/unveilhooks/ls.unveilhooks.min.js');
        wp_enqueue_script('bgset', 'https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.2.2/plugins/bgset/ls.bgset.min.js');
        wp_enqueue_script('lazysizes', 'https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.2.2/lazysizes.min.js');

        wp_localize_script('lazysizes-config', 'fifuLazyVars', [
            'fifu_video' => fifu_is_on("fifu_video"),
            'fifu_horizontal_expansion' => (class_exists('WooCommerce') && is_product()) && fifu_is_on("fifu_video") && fifu_is_avada_active(),
            'fifu_show_placeholder' => !fifu_is_newspaper_active(),
            'fifu_flickr' => fifu_is_on('fifu_flickr'),
        ]);
    }

    if (fifu_hover_selected()) {
        wp_register_style('fifu-hover', plugins_url('/html/css/hover.css', __FILE__), array(), fifu_version_number());
        wp_enqueue_style('fifu-hover');
    }

    if (fifu_is_on('fifu_slider')) {
        wp_register_style('fifu-slider-style', plugins_url('/html/css/slider.css', __FILE__), array(), fifu_version_number());
        wp_enqueue_style('fifu-slider-style');
    }

    if (class_exists('WooCommerce')) {
        wp_register_style('fifu-woo', plugins_url('/html/css/woo.css', __FILE__), array(), fifu_version_number());
        wp_enqueue_style('fifu-woo');
        wp_add_inline_style('fifu-woo', 'img.zoomImg {display:' . fifu_woo_zoom() . ' !important}');
    }

    if (fifu_is_on('fifu_mouse_youtube'))
        wp_enqueue_script('youtube', 'https://www.youtube.com/iframe_api');

    if (fifu_is_on('fifu_mouse_vimeo'))
        wp_enqueue_script('vimeo', 'https://f.vimeocdn.com/js/froogaloop2.min.js');

    if (fifu_is_on('fifu_video'))
        wp_enqueue_style('dashicons');

    // js
    wp_enqueue_script('fifu-image-js', plugins_url('/html/js/image.js', __FILE__), array('jquery'), fifu_version_number());
    wp_localize_script('fifu-image-js', 'fifuImageVars', [
        'fifu_lazy' => fifu_is_on("fifu_lazy"),
        'fifu_should_crop' => fifu_should_crop(),
        'fifu_slider' => fifu_is_on("fifu_slider"),
        'fifu_hover_selected' => fifu_hover_selected() ? 'on' : 'off',
        'fifu_hover_selector' => get_option("fifu_hover_selector"),
        'fifu_is_front_page' => is_front_page(),
        'fifu_hover' => get_option("fifu_hover"),
        'fifu_is_shop' => (class_exists('WooCommerce') && is_shop()) ? 'on' : 'off',
        'fifu_crop_selectors' => fifu_crop_selectors(),
        'fifu_fit' => get_option('fifu_fit'),
        'fifu_crop_ratio' => get_option('fifu_crop_ratio'),
        'fifu_crop_default' => get_option('fifu_crop_default'),
        'fifu_crop_ignore_parent' => get_option('fifu_crop_ignore_parent'),
        'fifu_woo_lbox_enabled' => fifu_woo_lbox(),
        'fifu_woo_zoom' => fifu_woo_zoom(),
        'fifu_is_product' => class_exists('WooCommerce') && is_product(),
        'fifu_error_url' => get_option('fifu_error_url'),
        'fifu_crop_delay' => get_option('fifu_crop_delay'),
        'fifu_is_flatsome_active' => fifu_is_flatsome_active(),
        'fifu_rest_url' => esc_url_raw(rest_url()),
        'fifu_nonce' => wp_create_nonce('wp_rest'),
    ]);
}

function fifu_add_social_tag_yoast() {
    if (get_post_meta(get_the_ID(), '_yoast_wpseo_opengraph-image', true) || get_post_meta(get_the_ID(), '_yoast_wpseo_twitter-image', true))
        return;
    return fifu_main_image_url(get_the_ID());
}

function fifu_add_social_tag_yoast_list($object) {
    if (get_post_meta(get_the_ID(), '_yoast_wpseo_opengraph-image', true) || get_post_meta(get_the_ID(), '_yoast_wpseo_twitter-image', true))
        return;
    $object->add_image(fifu_main_image_url(get_the_ID()));
}

function fifu_add_social_tags() {
    $post_id = get_the_ID();
    $title = str_replace("'", "&#39;", get_the_title($post_id));
    $description = str_replace("'", "&#39;", wp_strip_all_tags(get_post_field('post_excerpt', $post_id)));

    if (fifu_is_off('fifu_social'))
        return;

    global $wpdb;
    $arr = $wpdb->get_col($wpdb->prepare("SELECT meta_value FROM $wpdb->postmeta WHERE post_id = %d AND meta_key LIKE %s", $post_id, 'fifu_%image_url%'));

    if (empty($arr)) {
        $url = fifu_main_image_url($post_id);
        $url = $url ? $url : get_the_post_thumbnail_url($post_id);
        if ($url)
            $arr = array($url);
    }

    foreach ($arr as $url) {
        if ($url)
            include 'html/og-image.html';
    }

    if (fifu_is_off('fifu_social_image_only'))
        include 'html/social.html';

    foreach ($arr as $url) {
        if ($url)
            include 'html/twitter-image.html';
    }
}

function fifu_video_add_social_tags() {
    $post_id = get_the_ID();
    $url = get_post_meta($post_id, 'fifu_video_url', true);
    $title = str_replace("'", "&#39;", strip_tags(get_the_title($post_id)));
    $description = str_replace("'", "&#39;", str_replace('"', '&#34;', wp_strip_all_tags(get_post_field('post_excerpt', $post_id))));
    $video_id = fifu_video_id($url);
    $video_src = fifu_video_src($url);
    $video_url = $video_id == null ? $url : fifu_video_social_url($video_id);
    $video_img = fifu_video_social_img($url);

    if ($url)
        include 'html/social-video.html';
}

function fifu_add_lightslider() {
    if (fifu_is_on('fifu_slider')) {
        // slider
        wp_enqueue_script('fifu-lightslider', plugins_url('/html/js/lightslider.js', __FILE__), array('jquery'), fifu_version_number());
        wp_localize_script('fifu-lightslider', 'fifuSliderVars', [
            'fifu_lazy' => fifu_is_on("fifu_lazy"),
        ]);

        // css
        wp_enqueue_style('lightslider-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/css/lightslider.min.css');

        // js
        wp_enqueue_script('fifu-slider-js', plugins_url('/html/js/lightsliderConfig.js', __FILE__), array('jquery'), fifu_version_number());
        wp_localize_script('fifu-slider-js', 'fifuSliderVars', [
            'fifu_slider_speed' => get_option('fifu_slider_speed'),
            'fifu_slider_auto' => fifu_is_on('fifu_slider_auto'),
            'fifu_slider_pause' => get_option('fifu_slider_pause'),
            'fifu_slider_ctrl' => fifu_is_on('fifu_slider_ctrl'),
            'fifu_slider_stop' => fifu_is_on('fifu_slider_stop'),
            'fifu_slider_gallery' => fifu_is_on('fifu_slider_gallery'),
            'fifu_slider_thumb' => fifu_is_on('fifu_slider_thumb'),
            'fifu_should_crop' => fifu_should_crop(),
            'fifu_lazy' => fifu_is_on("fifu_lazy"),
            'fifu_is_product' => class_exists('WooCommerce') && is_product(),
            'fifu_url' => fifu_main_image_url(get_the_ID()),
        ]);

        // gallery
        wp_enqueue_script('lightgallery', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/1.6.12/js/lightgallery-all.min.js');
        wp_enqueue_style('lightgallery-style', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/1.6.12/css/lightgallery.min.css');
    }
}

function fifu_add_video() {
    if (fifu_is_on('fifu_video')) {
        // css
        wp_register_style('fifu-video-css', plugins_url('/html/css/video.css', __FILE__), array(), fifu_version_number());
        wp_enqueue_style('fifu-video-css');

        // Dynamic CSS
        $position = fifu_is_avada_active() ? '' : 'relative';
        $inline_style1 = '.fifu_play {position: ' . $position . '; width: 100%; z-index:' . get_option('fifu_video_zindex') . '; /* no zoom */}';
        $inline_style2 = '.fifu_play .btn:hover {background-color: ' . get_option('fifu_video_color') . '; opacity: 1;}';
        wp_add_inline_style('fifu-video-css', $inline_style1);
        wp_add_inline_style('fifu-video-css', $inline_style2);

        // fancy-box
        wp_enqueue_style('fancy-box-css', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css');
        wp_enqueue_script('fancy-box-js', 'https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js');

        // js
        wp_enqueue_script('fifu-video-js', plugins_url('/html/js/video.js', __FILE__), array('jquery'), fifu_version_number());
        wp_localize_script('fifu-video-js', 'fifuVideoVars', [
            'fifu_is_flatsome_active' => fifu_is_flatsome_active(),
            'fifu_is_home' => (is_home() || (class_exists("WooCommerce") && is_shop()) || is_archive() || is_search()),
            'fifu_is_shop' => class_exists("WooCommerce") && is_shop(),
            'fifu_is_page' => is_page(),
            'fifu_is_post' => is_singular('post'),
            'fifu_video_thumb_enabled_home' => fifu_video_thumb_enabled_home(),
            'fifu_video_thumb_enabled_page' => fifu_video_thumb_enabled_page(),
            'fifu_video_thumb_enabled_post' => fifu_video_thumb_enabled_post(),
            'fifu_video_thumb_enabled_cpt' => fifu_video_thumb_enabled_cpt(),
            'fifu_video_min_width' => get_option('fifu_video_min_width'),
            'fifu_is_home_or_shop' => fifu_is_home_or_shop(),
            'fifu_is_front_page' => is_front_page(),
            'fifu_video_black' => fifu_is_on("fifu_video_black") ? 'on' : 'off',
            'fifu_lazy_src_type' => fifu_lazy_src_type(),
            'fifu_mouse_vimeo_enabled' => fifu_mouse_vimeo_enabled(),
            'fifu_mouse_youtube_enabled' => fifu_mouse_youtube_enabled(),
            'fifu_loop_enabled' => fifu_loop_enabled() ? 'on' : 'off',
            'fifu_autoplay_enabled' => fifu_autoplay_enabled(),
            'fifu_video_related_enabled' => fifu_video_related_enabled(),
            'fifu_video_mute_enabled' => fifu_video_mute_enabled(),
            'fifu_video_background_enabled' => fifu_video_background_enabled(),
            'fifu_video_gallery_icon_enabled' => fifu_is_on('fifu_video_gallery_icon'),
            'fifu_is_elementor_active' => fifu_is_elementor_active(),
            'fifu_woocommerce' => class_exists("WooCommerce") ? 'on' : 'off',
            'fifu_is_divi_active' => fifu_is_divi_active(),
            'fifu_essential_grid_status' => fifu_is_essential_grid_active() ? 'on' : 'off',
            'fifu_is_product' => class_exists('WooCommerce') && is_product(),
            'fifu_play_button_enabled' => fifu_is_on("fifu_video_play_button"),
            'fifu_play_hide_grid' => fifu_is_on('fifu_video_play_hide_grid'),
            'fifu_url' => fifu_main_image_url(get_the_ID()),
            'fifu_is_play_type_inline' => get_option('fifu_play_type') == 'inline',
            'fifu_is_play_type_lightbox' => get_option('fifu_play_type') == 'lightbox',
            'fifu_video_color' => get_option('fifu_video_color'),
            'fifu_should_hide' => fifu_should_hide(),
            'fifu_gallery_selector' => get_option("fifu_gallery_selector"),
            'fifu_should_wait_ajax' => fifu_should_wait_ajax(),
            'fifu_lazy' => fifu_is_on("fifu_lazy"),
        ]);
    }
}

function fifu_add_shortcode() {
    if (fifu_is_on('fifu_shortcode')) {
        // css
        wp_register_style('fifu-shortcode-css', plugins_url('/html/css/shortcode.css', __FILE__), array(), fifu_version_number());
        wp_enqueue_style('fifu-shortcode-css');
    }
}

function fifu_apply_css() {
    if (fifu_is_off('fifu_wc_lbox'))
        echo '<style>[class$="woocommerce-product-gallery__trigger"] {display:none !important;}</style>';
}

add_filter('wp_get_attachment_image_attributes', 'fifu_wp_get_attachment_image_attributes', 10, 3);

function fifu_wp_get_attachment_image_attributes($attr, $attachment, $size) {
    return $attr;
}

add_filter('woocommerce_product_get_image', 'fifu_woo_replace', 10, 5);

function fifu_woo_replace($html, $product, $woosize) {
    return fifu_replace($html, $product->get_id(), null, null, null);
}

add_filter('post_thumbnail_html', 'fifu_replace', 10, 5);

function fifu_replace($html, $post_id, $post_thumbnail_id, $size, $attr) {
    if (!$html)
        return $html;

    $width = fifu_get_attribute('width', $html);
    $height = fifu_get_attribute('height', $html);
    $original_class = fifu_get_attribute('class', $html);

    if (fifu_is_html_shortcode($html)) {
        $shortcode = get_post_meta($post_id, 'fifu_shortcode', true);
        $ratio = get_post_meta($post_id, 'fifu_shortcode_ratio', true);
        return '<div fifu-shortcode="1"  style="--aspect-ratio:' . $ratio . ';">' . do_shortcode($shortcode) . '</div>';
    }

    if (fifu_is_on('fifu_lazy') && !is_admin()) {
        if (strpos($html, ' src=') !== false && strpos($html, ' data-src=') === false)
            $html = str_replace(" src=", " data-src=", $html);
        if (strpos($html, ' src=') !== false && strpos($html, ' data-src=') !== false)
            $html = preg_replace("/ src=[\'\"][^\'\"]+[\'\"]/", ' ', $html);
    }

    $videoUrl = get_post_meta($post_id, 'fifu_video_url', true);
    if (fifu_is_on('fifu_video') && $videoUrl)
        return $html;

    $datasrc = fifu_get_attribute('data-src', $html);
    $src = $datasrc ? $datasrc : fifu_get_attribute('src', $html);
    if (isset($_POST[$src])) {
        $data = $_POST[$src];
        if (strpos($html, 'fifu-replaced') !== false)
            return $html;
    }

    $sliderUrl = get_post_meta($post_id, 'fifu_slider_image_url_0', true);
    if ($sliderUrl && fifu_is_on('fifu_slider')) {
        if (fifu_show_slider($sliderUrl))
            return fifu_slider_get_html($post_id, $original_class, null, null);
        return $html;
    }

    $url = get_post_meta($post_id, 'fifu_image_url', true);

    $delimiter = fifu_get_delimiter('src', $html);
    if (fifu_is_on('fifu_dynamic_alt')) {
        $alt = get_the_title($post_id);
        $html = preg_replace('/alt=[\'\"][^[\'\"]*[\'\"]/', 'alt=' . $delimiter . $alt . $delimiter, $html);
    } else {
        if ($url) {
            $alt = get_post_meta($post_id, 'fifu_image_alt', true);
            $html = preg_replace('/alt=[\'\"][^[\'\"]*[\'\"]/', 'alt=' . $delimiter . $alt . $delimiter . ' title=' . $delimiter . $alt . $delimiter, $html);
        } else
            $alt = null;
    }

    // position
    $position = get_post_meta($post_id, 'fifu_position', true);
    if ($position)
        $html = str_replace('<img', '<img fifu-position="' . $position . '"', $html);

    // onerror
    $error_url = get_option('fifu_error_url');
    if ($error_url)
        $html = str_replace('/>', sprintf(' onerror="this.src=\'%s\'"/>', $error_url), $html);

    if ($url)
        return $html;

    $url = !$sliderUrl ? $url : $sliderUrl;

    return !$url ? $html : fifu_get_html($url, $alt, $width, $height);
}

function fifu_show_slider($sliderUrl) {
    return $sliderUrl && is_valid_slider_locale();
}

function fifu_is_url($var) {
    return strpos($var, 'http') === 0;
}

function fifu_get_html($url, $alt, $width, $height) {
    $css = '';
    if (fifu_is_video($url)) {
        $cls = 'fifu-video';
        if (class_exists('WooCommerce') && is_cart())
            $cls = 'fifu';
        else {
            if (fifu_is_off('fifu_lazy'))
                $css = 'opacity:0';
        }
    } else {
        $cls = 'fifu';
    }

    if (fifu_should_hide()) {
        $css = 'display:none';
        $cls = 'fifu';
    }

    return sprintf('<img class="%s" %s alt="%s" title="%s" style="%s" data-large_image="%s" data-large_image_width="%s" data-large_image_height="%s" onerror="%s" width="%s" height="%s">', $cls, fifu_lazy_url($url), $alt, $alt, $css, $url, "800", "600", "jQuery(this).hide();", $width, $height);
}

function fifu_slider_get_html($post_id, $original_class, $gallery_class, $gallery_css) {
    $css = fifu_should_hide() ? 'display:none' : '';

    $ratio = get_post_meta($post_id, 'fifu_slider_ratio', true);
    $ratio = $ratio ? 'fifu-ratio="' . $ratio . '"' : '';

    $class = fifu_is_lazy() ? "fifu lazyload" : "fifu";
    $class .= ' ' . $original_class;

    $gallery_css = $gallery_css ? 'style="' . $gallery_css . '"' : '';

    $html = sprintf('<div class="fifu-slider %s" id="fifu-slider-%s" %s %s>', $gallery_class, $post_id, $ratio, $gallery_css);
    $html = $html . '<ul id="image-gallery" class="gallery list-unstyled cS-hidden">';
    $max = get_option('fifu_spinner_slider');
    for ($i = 0; $i < $max; $i++) {
        $url = get_post_meta($post_id, 'fifu_slider_image_url_' . $i, true);

        if (fifu_is_jetpack_active())
            $url = fifu_get_photon_slider_url($url);

        if ($url) {
            if (is_from_flickr($url)) {
                $html = $html . sprintf(
                                '<li data-thumb="%s" data-src="%s" data-srcset="%s"><img data-src="%s" data-srcset="%s" data-sizes="auto" style="%s" class="%s" onerror="%s"/></li>',
                                $url,
                                FIFU_PLACEHOLDER,
                                fifu_flickr_get_set($url),
                                preg_replace('/([_][a-z]){0,1}.jpg/', '_t.jpg', $url),
                                fifu_flickr_get_set($url),
                                $css,
                                (fifu_is_lazy() && $i == 0 ? "fifu lazyload" : "fifu") . ' ' . $original_class,
                                "jQuery(this).hide();"
                );
                continue;
            } else if (is_from_speedup($url)) {
                $html = $html . sprintf(
                                '<li data-thumb="%s" data-src="%s" data-srcset="%s"><img data-src="%s" data-srcset="%s" data-sizes="auto" style="%s" class="%s" onerror="%s"/></li>',
                                $url,
                                FIFU_PLACEHOLDER,
                                fifu_speedup_get_set($url),
                                str_replace('original', '100', $url),
                                fifu_speedup_get_set($url),
                                $css,
                                (fifu_is_lazy() && $i == 0 ? "fifu lazyload" : "fifu") . ' ' . $original_class,
                                "jQuery(this).hide();"
                );
                continue;
            } else if (is_from_jetpack($url) && fifu_is_lazy()) {
                $html = $html . sprintf(
                                '<li data-thumb="%s" data-src="%s" data-srcset="%s"><img data-src="%s" data-srcset="%s" data-sizes="auto" style="%s" class="%s" onerror="%s"/></li>',
                                str_replace('?ssl=1', '?w=175&resize=175&ssl=1', $url),
                                FIFU_PLACEHOLDER,
                                fifu_jetpack_get_set($url, true),
                                str_replace('?ssl=1', '?w=175&resize=175&ssl=1', $url),
                                fifu_jetpack_get_set($url, true),
                                $css,
                                (fifu_is_lazy() && $i == 0 ? "fifu lazyload" : "fifu") . ' ' . $original_class,
                                "jQuery(this).hide();"
                );
                continue;
            }
            $html = $html . sprintf(
                            '<li data-thumb="%s" data-src="%s"><img %s style="%s" class="%s" onerror="%s"/></li>',
                            $url,
                            $url,
                            fifu_lazy_url($url),
                            $css,
                            (fifu_is_lazy() && $i == 0 ? "fifu lazyload" : "fifu") . ' ' . $original_class,
                            "jQuery(this).hide();"
            );
        }
    }
    // add status
    $html = str_replace('<img ', '<img fifu-replaced="1" ', $html);
    return $html . '</ul></div>';
}

function fifu_is_html_shortcode($html) {
    $attr = fifu_get_attribute('src', $html);
    if (strpos($attr, 'shortcode.svg') !== false)
        return true;

    $attr = fifu_get_attribute('fifu-shortcode', $html);
    if (strpos($attr, '1') !== false)
        return true;

    return false;
}

function fifu_is_lazy() {
    return fifu_is_on('fifu_lazy');
}

function is_valid_slider_locale() {
    return !(class_exists('WooCommerce') && is_cart());
}

function is_slider_empty($post_id) {
    for ($i = 0; $i < 5; $i++)
        if (get_post_meta($post_id, 'fifu_slider_image_url_' . $i, true))
            return false;
    return true;
}

add_filter('the_content', 'fifu_add_to_content');

function fifu_add_to_content($content) {
    return is_singular() && has_post_thumbnail() && ((is_singular('post') && fifu_is_on('fifu_content')) or ( is_singular('page') && fifu_is_on('fifu_content_page'))) ? get_the_post_thumbnail() . $content : $content;
}

function fifu_should_hide() {
    return !is_front_page() && ((is_singular('post') && fifu_is_on('fifu_hide_post')) || (is_singular('page') && fifu_is_on('fifu_hide_page')) || (is_singular(get_post_type(get_the_ID())) && fifu_is_cpt() && fifu_is_on('fifu_hide_cpt')));
}

function fifu_is_cpt() {
    return in_array(get_post_type(get_the_ID()), array_diff(fifu_get_post_types(), array('post', 'page')));
}

function fifu_should_crop() {
    return fifu_is_on('fifu_same_size');
}

function fifu_crop_selectors() {
    $concat = '';
    for ($x = 0; $x <= 4; $x++) {
        $selector = get_option('fifu_crop' . $x);
        if ($selector)
            $concat = $concat . ',' . $selector;
    }
    return $concat;
}

function fifu_hover_selected() {
    return get_option('fifu_hover');
}

function fifu_main_image_url($post_id) {
    $url = get_post_meta($post_id, 'fifu_slider_image_url_0', true);

    if (!$url)
        $url = get_post_meta($post_id, 'fifu_image_url', true);

    if (!$url) {
        $video_url = get_post_meta($post_id, 'fifu_video_url', true);
        $url = fifu_video_img_large($video_url, $post_id, false);
    }

    if (!$url && fifu_no_internal_image($post_id) && (get_option('fifu_default_url') && fifu_is_on('fifu_enable_default_url')))
        $url = get_option('fifu_default_url');

    $url = htmlspecialchars_decode($url);

    return str_replace("'", "", $url);
}

function fifu_no_internal_image($post_id) {
    return get_post_meta($post_id, '_thumbnail_id', true) == -1 || get_post_meta($post_id, '_thumbnail_id', true) == null || get_post_meta($post_id, '_thumbnail_id', true) == get_option('fifu_default_attach_id');
}

function fifu_lazy_url($url) {
    if (fifu_is_off('fifu_lazy'))
        return 'src="' . $url . '"';
    return 'data-src="' . $url . '"';
}

function fifu_lazy_src_type() {
    if (fifu_is_off('fifu_lazy'))
        return 'src=';
    return 'data-src=';
}

function fifu_valid_url($url) {
    return !empty($url) && (fifu_is_off('fifu_valid') || fifu_from_instagram($url)) ? true : strpos(@get_headers(str_replace(" ", "%20", $url))[0], '200 OK') !== false;
}

function fifu_is_main_page() {
    return is_home() || (class_exists('WooCommerce') && is_shop());
}

function fifu_has_internal_image($post_id) {
    $featured_image = get_post_meta($post_id, '_thumbnail_id', true);
    return $featured_image && $featured_image != -1 && $featured_image != get_option('fifu_fake_attach_id');
}

function fifu_is_in_editor() {
    return !is_admin() || get_current_screen() == null ? false : get_current_screen()->parent_base == 'edit' || get_current_screen()->is_block_editor;
}

function fifu_get_default_url() {
    return wp_get_attachment_url(get_option('fifu_default_attach_id'));
}

// rss

add_filter('rss2_ns', function() {
    if (fifu_is_on('fifu_rss'))
        echo 'xmlns:media="http://search.yahoo.com/mrss/"';
});

add_action('rss2_item', 'fifu_add_rss');

function fifu_add_rss() {
    if (fifu_is_off('fifu_rss'))
        return;

    global $post;
    if (has_post_thumbnail($post->ID)) {
        $thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID));
        $rss_width = get_option('fifu_rss_width');
        $width = $rss_width ? 'width="' . $rss_width . '"' : '';
        if (is_array($thumbnail)) {
            echo '<media:content url="' . explode('?', $thumbnail[0])[0] . '" medium="image" ' . $width . '></media:content>
			';
        }
    }
}

