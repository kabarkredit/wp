<?php

function fifu_get_attribute($attribute, $html) {
    $attribute = $attribute . '=';
    if (strpos($html, $attribute) === false)
        return null;

    $aux = explode($attribute, $html);
    if ($aux)
        $aux = $aux[1];

    $quote = $aux[0];

    if ($quote == '&') {
        preg_match('/^&[^;]+;/', $aux, $matches);
        if ($matches)
            $quote = $matches[0];
    }

    $aux = explode($quote, $aux);
    if ($aux)
        return $aux[1];

    return null;
}

function fifu_replace_attribute($html, $attribute, $value) {
    $attribute = $attribute . '=';
    if (strpos($html, $attribute) === false)
        return $html;
    $matches = array();
    preg_match('/' . $attribute . '[^ ]+/', $html, $matches);
    return str_replace($matches[0], $attribute . '"' . $value . '"', $html);
}

function fifu_is_on($option) {
    return get_option($option) == 'toggleon';
}

function fifu_is_off($option) {
    return get_option($option) == 'toggleoff';
}

function fifu_get_post_types() {
    $arr = array();
    foreach (get_post_types() as $post_type) {
        if (post_type_supports($post_type, 'thumbnail'))
            array_push($arr, $post_type);
    }
    return $arr;
}

function fifu_is_home_or_shop() {
    return (is_home() || (class_exists('WooCommerce') && (is_shop() || is_product_category())));
}

function fifu_is_instagram_url($url) {
    return strpos($url, 'www.instagram.com') !== false;
}

function fifu_get_delimiter($property, $html) {
    $delimiter = explode($property . '=', $html);
    return $delimiter ? substr($delimiter[1], 0, 1) : null;
}

function fifu_is_ajax_call() {
    return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') || wp_doing_ajax();
}

function fifu_normalize($tag) {
    $tag = str_replace('amp;', '', $tag);
    $tag = str_replace('#038;', '', $tag);
    return $tag;
}

function fifu_starts_with($text, $substr) {
    return substr($text, 0, strlen($substr)) === $substr;
}

function fifu_get_domain() {
    $url = get_home_url();

    $aux = explode('//', $url);
    if ($aux)
        $part = $aux[1];

    $aux = explode('/', $part);
    if ($aux)
        return $aux[0];

    return null;
}

function fifu_get_youtube_thumb_api($url, $att_id) {
    $response = wp_remote_get('https://www.googleapis.com/youtube/v3/videos?key=AIzaSyArLBLrvdQFG75fzSGKAwYIpg3sGQBy-xA&part=snippet&id=' . fifu_youtube_id_from_thumb($url));
    if ($response && !is_wp_error($response) && isset(json_decode($response['body'])->items[0]->snippet->thumbnails)) {
        $thumbnails = json_decode($response['body'])->items[0]->snippet->thumbnails;
        if (!isset($thumbnails->maxres)) {
            update_post_meta($att_id, 'fifu_yt_res', 'mqdefault');
            $url = str_replace('maxresdefault', 'mqdefault', $url);
            update_post_meta($att_id, '_wp_attached_file', $url);
            global $wpdb;
            $wpdb->update($wpdb->posts, ['guid' => $url], ['ID' => $att_id]);
        } else
            update_post_meta($att_id, 'fifu_yt_res', 'maxresdefault');
    }
    return $url;
}

function fifu_get_tags($post_id) {
    $tags = get_the_tags($post_id);
    if (!$tags)
        return null;

    $names = null;
    foreach ($tags as $tag)
        $names .= $tag->name . ' ';
    return $names ? rtrim($names) : null;
}

function fifu_check_youtube_thumb($url, $att_id) {
    if (!fifu_is_youtube_video($url))
        return $url;

    $res = get_post_meta($att_id, 'fifu_yt_res', true);
    if ($res)
        return $url;

    if (!fifu_is_in_editor())
        return fifu_get_youtube_thumb_api($url, $att_id);

    return $url;
}

function fifu_check_instagram_thumb($url, $att_id, $post_id) {
    if (!fifu_is_old_instagram_url($url))
        return $url;

    if (!fifu_is_in_editor()) {
        $db_url = get_post_meta($post_id, 'fifu_image_url', true);
        if ($db_url == $url) {
            $new_url = fifu_api_get_instagram_thumb($url);
            if ($new_url) {
                update_post_meta($post_id, 'fifu_image_url', $new_url);
                update_post_meta($att_id, '_wp_attached_file', $new_url);
                global $wpdb;
                $wpdb->update($wpdb->posts, ['guid' => $new_url], ['ID' => $att_id]);
                return $new_url;
            }
        } else
            return $db_url;
    }
    return $url;
}

function fifu_get_home_url() {
    return explode('//', get_home_url())[1];
}

function fifu_dashboard() {
    return !is_home() &&
            !is_singular('post') &&
            !is_author() &&
            !is_search() &&
            !is_singular('page') &&
            !is_singular('product') &&
            !is_archive() &&
            (!class_exists('WooCommerce') || (class_exists('WooCommerce') && (!is_shop() && !is_product_category() && !is_cart())));
}

// developers

function fifu_dev_set_image($post_id, $image_url) {
    fifu_update_or_delete($post_id, 'fifu_image_url', esc_url_raw(rtrim($image_url)));
    fifu_update_fake_attach_id($post_id);
}

// active plugins

function fifu_is_elementor_active() {
    return is_plugin_active('elementor/elementor.php') || is_plugin_active('elementor-pro/elementor-pro.php');
}

function fifu_is_elementor_editor() {
    if (!fifu_is_elementor_active())
        return false;
    return \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode();
}

function fifu_is_essential_grid_active() {
    return is_plugin_active('essential-grid/essential-grid.php');
}

function fifu_is_jetpack_active() {
    if (!is_plugin_active('jetpack/jetpack.php'))
        return false;

    if (defined('FIFU_DEV_DEBUG') && FIFU_DEV_DEBUG)
        return true;

    return function_exists('jetpack_photon_url') && class_exists('Jetpack') && method_exists('Jetpack', 'get_active_modules') && in_array('photon', Jetpack::get_active_modules());
}

function fifu_is_yith_woocommerce_wishlist_active() {
    return is_plugin_active('yith-woocommerce-wishlist/init.php');
}

function fifu_is_yith_woocommerce_wishlist_ajax_enabled() {
    return 'yes' == get_option('yith_wcwl_ajax_enable', 'no');
}

// active themes

function fifu_is_flatsome_active() {
    return 'flatsome' == get_option('template');
}

function fifu_is_divi_active() {
    return 'divi' == strtolower(get_option('template'));
}

function fifu_is_avada_active() {
    return 'avada' == strtolower(get_option('template'));
}

function fifu_is_newspaper_active() {
    return 'newspaper' == strtolower(get_option('template'));
}

// plugin: accelerated-mobile-pages

function fifu_amp_url($url, $width, $height) {
    return array(0 => $url, 1 => $width, 2 => $height);
}

