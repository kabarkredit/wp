<?php

function fifu_woo_zoom() {
    return fifu_is_on('fifu_wc_zoom') ? 'inline' : 'none';
}

function fifu_woo_lbox() {
    return fifu_is_on('fifu_wc_lbox');
}

function fifu_woo_theme() {
    return file_exists(get_template_directory() . '/woocommerce');
}

# https://docs.woocommerce.com/document/image-sizes-theme-developers/

function fifu_woo_get_image_size() {
    if (class_exists('WooCommerce')) {
        if (is_shop())
            return wc_get_image_size('woocommerce_get_image_size_woocommerce_thumbnail');
        if (is_product())
            return wc_get_image_size('woocommerce_get_image_size_woocommerce_single');
    }
}

define('FIFU_FIX_IMAGES_WITHOUT_DIMENSIONS', "
    function fix_images_without_dimensions() {
        jQuery('img[data-large_image_height=0]').each(function () {
            if (jQuery(this)[0].naturalWidth <= 2)
                return;

            jQuery(this)
                .attr('data-large_image_width', jQuery(this)[0].naturalWidth)
                .attr('data-large_image_height', jQuery(this)[0].naturalHeight);
        });
    }
    fix_images_without_dimensions();"
);

function fifu_woocommerce_gallery_image_html_attachment_image_params($params, $attachment_id, $image_size, $main_image) {
    // fix zoom
    if ($params['data-large_image_width'] == 0) {
        $params['data-large_image_width'] = 1920;
        $params['data-large_image_height'] = 0;
    }

    // fix lightbox
    if (is_product())
        $params['onload'] = FIFU_FIX_IMAGES_WITHOUT_DIMENSIONS;

    return $params;
}

add_filter('woocommerce_gallery_image_html_attachment_image_params', 'fifu_woocommerce_gallery_image_html_attachment_image_params', 10, 4);

function fifu_woo_template_override($template, $slug) {
    // global $post;
    // if (get_post_meta($post->ID, 'fifu_slider_image_url_0', true)) {
    //     if  ($slug == 'single-product/product-image.php')
    //         return FIFU_INCLUDES_DIR . '/template.php'; 
    // }
    return $template;
}

add_filter('wc_get_template', 'fifu_woo_template_override', 10, 2);

function fifu_in_gallery($att_id) {
    $att_post = get_post($att_id);
    $post_parent = get_post($att_post->post_parent);
    if (!isset($post_parent->ID))
        return false;
    $gallery_ids = get_post_meta($post_parent->ID, '_product_image_gallery', true);
    if ($gallery_ids)
        $gallery_ids = explode(',', $gallery_ids);
    if (is_array($gallery_ids))
        return in_array($att_id, $gallery_ids);
    return false;
}

add_action('woocommerce_product_duplicate', 'fifu_woocommerce_product_duplicate', 10, 1);

function fifu_woocommerce_product_duplicate($array) {
    if (!$array || !$array->get_meta_data())
        return;

    $post_id = $array->get_id();
    foreach ($array->get_meta_data() as $meta_data) {
        $data = $meta_data->get_data();
        if (in_array($data['key'], array('fifu_image_url', 'fifu_video_url', 'fifu_slider_image_url_0'))) {
            delete_post_meta($post_id, '_thumbnail_id');
        } else if (
                (strpos($data['key'], 'fifu_image_url_') !== false) ||
                (strpos($data['key'], 'fifu_video_url_') !== false) ||
                (strpos($data['key'], 'fifu_slider_image_url_') !== false)) {
            delete_post_meta($post_id, '_product_image_gallery');
        }
    }
}

