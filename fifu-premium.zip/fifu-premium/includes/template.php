<?php

global $post;
echo fifu_slider_get_html(
        $post->ID, null,
        'fifu-woo-gallery woocommerce-product-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-4 images',
        '');
?>
