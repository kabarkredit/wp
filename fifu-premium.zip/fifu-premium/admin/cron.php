<?php

function fifu_add_cron_schedules($schedules) {
    if (!isset($schedules["fifu_schedule_metadata"])) {
        $schedules['fifu_schedule_metadata'] = array(
            'interval' => get_option('fifu_spinner_cron_metadata') * 60,
            'display' => __('fifu-metadata')
        );
    }
    if (!isset($schedules["fifu_schedule_auto_set"])) {
        $schedules['fifu_schedule_auto_set'] = array(
            'interval' => 1 * 60,
            'display' => __('fifu-auto-set')
        );
    }
    if (!isset($schedules["fifu_schedule_isbn"])) {
        $schedules['fifu_schedule_isbn'] = array(
            'interval' => 1 * 60,
            'display' => __('fifu-isbn')
        );
    }
    return $schedules;
}

add_filter('cron_schedules', 'fifu_add_cron_schedules');

function fifu_create_metadata_hook() {
    if (fifu_is_off('fifu_fake'))
        return;

    // mutex
    $count = 0;
    $timeout = 10;
    $got_lock = true;
    $fp = fopen(ABSPATH . 'fifu-lock-schedule-metadata', 'w') or error_log('Cannot create lock file');
    while (!flock($fp, LOCK_EX | LOCK_NB, $wouldblock)) {
        if ($wouldblock && $count++ < $timeout)
            sleep(1);
        else {
            $got_lock = false;
            break;
        }
    }
    if (!$got_lock)
        return;

    $result = fifu_db_get_all_posts_without_meta();
    foreach ($result as $res) {
        fifu_split_lists($res->post_id);
        fifu_update_fake_attach_id($res->post_id);
    }

    if (fifu_is_on('fifu_auto_category'))
        fifu_db_insert_auto_category_image();

    $result = fifu_db_get_categories_without_meta();
    foreach ($result as $res)
        fifu_db_ctgr_update_fake_attach_id($res->term_id);
}

add_action('fifu_create_metadata_event', 'fifu_create_metadata_hook');

function fifu_create_auto_set_hook() {
    // mutex
    $count = 0;
    $timeout = 10;
    $got_lock = true;
    $fp = fopen(ABSPATH . 'fifu-lock-schedule-auto-set', 'w') or error_log('Cannot create lock file');
    while (!flock($fp, LOCK_EX | LOCK_NB, $wouldblock)) {
        if ($wouldblock && $count++ < $timeout)
            sleep(1);
        else {
            $got_lock = false;
            break;
        }
    }
    if (!$got_lock)
        return;

    // check request limit
    if (get_option('fifu_auto_set_blocked')) {
        $date = new DateTime();
        if ($date->getTimestamp() - strtotime(get_option('fifu_auto_set_blocked')) < 3600)
            return;
        delete_option('fifu_auto_set_blocked');
    }

    $width = get_option('fifu_auto_set_width');
    $height = get_option('fifu_auto_set_height');
    $blocklist = get_option('fifu_auto_set_blocklist');
    $blocklist = $blocklist ? explode(PHP_EOL, $blocklist) : null;

    $result = fifu_db_get_posts_without_featured_image();
    foreach ($result as $res) {
        if (!file_exists(ABSPATH . 'fifu-lock-schedule-auto-set') || !$res->post_title)
            return;

        $image = fifu_api_search($res->post_title, $width, $height, $blocklist);
        if ($image) {
            if (isset($image->url) && $image->url) {
                fifu_save_image_data($res->id, $image->url, $image->width, $image->height);
            } else if (isset($image->code) && in_array($image->code, array(400, 401, 403, 408, 425, 426, 429))) {
                update_option('fifu_auto_set_blocked', date("Y-m-d H:i:s"));
                sleep(3600);
                return;
            }
        } else
            sleep(60);
    }
}

add_action('fifu_create_auto_set_event', 'fifu_create_auto_set_hook');

function fifu_create_isbn_hook() {
    // mutex
    $count = 0;
    $timeout = 10;
    $got_lock = true;
    $fp = fopen(ABSPATH . 'fifu-lock-schedule-isbn', 'w') or error_log('Cannot create lock file');
    while (!flock($fp, LOCK_EX | LOCK_NB, $wouldblock)) {
        if ($wouldblock && $count++ < $timeout)
            sleep(1);
        else {
            $got_lock = false;
            break;
        }
    }
    if (!$got_lock)
        return;

    // check request limit
    if (get_option('fifu_isbn_blocked')) {
        $date = new DateTime();
        if ($date->getTimestamp() - strtotime(get_option('fifu_isbn_blocked')) < 3600)
            return;
        delete_option('fifu_isbn_blocked');
    }

    $result = fifu_db_get_isbns_without_featured_image();
    foreach ($result as $res) {
        if (!file_exists(ABSPATH . 'fifu-lock-schedule-isbn'))
            return;

        $isbn = $res->isbn;
        if (strpos($isbn, 'not-found') !== false || strpos($isbn, 'invalid') !== false || empty($isbn))
            continue;

        $post_id = $res->post_id;

        $image = fifu_api_isbn($isbn, null);
        if ($image) {
            if (isset($image->url) && $image->url) {
                fifu_save_image_data($post_id, $image->url, null, null);
            } else if (isset($image->code) && $image->code == 404) {
                $html = fifu_amazon_search($isbn);
                if ($html) {
                    $amazon_html = fifu_amazon_first_result($html, $isbn);
                    $image = fifu_api_isbn($isbn, $amazon_html);
                    if (isset($image->urls) && $image->urls) {
                        $url = explode("|", $image->urls)[0];
                        if ($url == 'https://images-na.ssl-images-amazon.com/images/I/01GmVhVRioL.gif')
                            update_post_meta($post_id, 'fifu_isbn', 'not-found:' . $isbn);
                        else
                            fifu_save_image_data($post_id, $url, null, null);
                    } else if (isset($image->code) && $image->code == 404) {
                        update_post_meta($post_id, 'fifu_isbn', 'not-found:' . $isbn);
                    }
                }
            }
            if (isset($image->code) && $image->code == 417)
                update_post_meta($post_id, 'fifu_isbn', 'invalid:' . $isbn);

            if (isset($image->code) && in_array($image->code, array(400, 401, 403, 408, 425, 426, 429))) {
                update_option('fifu_isbn_blocked', date("Y-m-d H:i:s"));
                return;
            }
        }
    }
}

add_action('fifu_create_isbn_event', 'fifu_create_isbn_hook');

function fifu_save_image_data($post_id, $url, $width, $height) {
    fifu_dev_set_image($post_id, $url);
    if ($width && $height) {
        $att_id = get_post_thumbnail_id($post_id);
        fifu_save_dimensions($att_id, $width, $height);
    }
}

