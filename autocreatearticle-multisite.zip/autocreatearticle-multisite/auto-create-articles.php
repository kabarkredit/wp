<?php
/*
Plugin Name: Auto Create Articles
Description: Automatically creates articles on multisite when an article is published on the main site.
Version: 1.2
Author: Iyan Romandani
*/

// Fungsi untuk mendapatkan respon dari API Groq AI dengan retry menggunakan cURL
function get_groq_ai_response($prompt, $retry = 3) {
    // Daftar API keys
    $api_keys = [
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
        "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",
    ];

    // Pilih API key secara acak
    $api_key = $api_keys[array_rand($api_keys)];
    $api_url = 'https://api.groq.com/openai/v1/chat/completions'; // Sesuaikan dengan URL endpoint Groq AI

    // Data yang akan dikirimkan ke Groq AI
    $data = array(
        'model' => 'llama-3-70b-8192',
        'prompt' => $prompt,
        'max_tokens' => 2048,
        'temperature' => 1,
        'top_p' => 1
    );

    // Konversi data menjadi format JSON
    $json_data = json_encode($data);

    // Buat header API dengan API key
    $headers = array(
        'Authorization: Bearer ' . $api_key,
        'Content-Type: application/json'
    );

    // Buat request POST ke API Groq AI menggunakan cURL
    $ch = curl_init($api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Eksekusi request dan ambil respons
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Periksa apakah permintaan gagal dan coba lagi jika perlu
    if ($http_code != 200 && $retry > 0) {
        return get_groq_ai_response($prompt, $retry - 1);
    }

    if ($http_code != 200) {
        return '';
    }

    $response_data = json_decode($response, true);
    return $response_data['choices'][0]['text'] ?? '';
}

// Fungsi untuk membuat artikel di WordPress dan mengembalikan URL
function create_article($title, $content, $categories, $tags, $site_id, $post_date) {
    switch_to_blog($site_id);

    $post_id = wp_insert_post(array(
        'post_title' => $title,
        'post_content' => $content,
        'post_status' => 'publish',
        'post_category' => $categories,
        'tags_input' => $tags,
        'post_date' => $post_date,
    ));

    $post_url = get_permalink($post_id);

    restore_current_blog();
    
    return $post_url;
}

// Fungsi untuk memperbarui file getpost.html dengan URL posting baru
function update_getpost_html($main_title, $post_data) {
    $file_path = ABSPATH . 'getpost.html';
    $content = "<h1>{$main_title}</h1><ol>";

    foreach ($post_data as $data) {
        $content .= "<li>{$data['title']} <br /> url : <a href=\"{$data['url']}\">{$data['url']}</a></li>";
    }

    $content .= "</ol>";

    file_put_contents($file_path, $content);
}

// Fungsi untuk mendapatkan judul, konten, kategori, dan tag dari API Groq AI dan membuat artikel di multi situs
function auto_create_articles($main_title, $main_post_date) {
    // 1. Dapatkan 15 judul baru
    $title_prompt = "Create 15 suitable titles to be used as posts related to the article \"${main_title}\".
title avoid the same problem topic.                   
Just give me the answer straight away without any other sentences that I get.
Answers are packaged in an array
use English language";
    $titles_response = get_groq_ai_response($title_prompt);
    $titles = json_decode($titles_response, true);

    // Dapatkan ID situs multi secara acak
    $sites = get_sites(array('fields' => 'ids'));
    shuffle($sites);
    $selected_sites = array_slice($sites, 0, 15);

    $post_data = [];

    // 2. Loop melalui 15 judul untuk membuat artikel
    foreach ($titles as $index => $title_new) {
        $title_new = trim($title_new);

        // Dapatkan konten artikel
        $content_prompt = "Create an article for me with the keyword '${title_new}'. Format article Full HTML use <h1> <h2> <h3> <p> <ul> <ol> <li>. don't have any <html> <body> <style> <header>. Tone 'Professional'. Just give the answer straight away without any other sentences that I get. use English language.";
        $content = get_groq_ai_response($content_prompt);

        // Dapatkan kategori
        $category_prompt = "Use English language. Create 2 good category for an article titled \"${title_new}\". The Answers Given Should be separated by commas. Just give the answer straight away without any other sentences that I get.";
        $categories_response = get_groq_ai_response($category_prompt);
        $categories = array_map('trim', explode(',', $categories_response));

        // Dapatkan tag
        $tag_prompt = "Use English language. Create 5 good keywords for an article titled \"${title_new}\". The Answers Given Should be separated by commas. Just give the answer straight away without any other sentences that I get.";
        $tags_response = get_groq_ai_response($tag_prompt);
        $tags = array_map('trim', explode(',', $tags_response));

        // Buat artikel di situs yang dipilih secara acak dan dapatkan URL
        $post_url = create_article($title_new, $content, $categories, $tags, $selected_sites[$index], $main_post_date);
        $post_data[] = [
            'title' => $title_new,
            'url' => $post_url
        ];
    }

    // Perbarui file getpost.html dengan data posting baru
    update_getpost_html($main_title, $post_data);
}

// Hook ke action yang sesuai ketika artikel dibuat di domain utama
add_action('publish_post', function($post_id) {
    $post = get_post($post_id);

    // Pastikan hanya melakukan ini untuk postingan di domain utama
    if (is_main_site()) {
        auto_create_articles($post->post_title, $post->post_date);
    }
});
