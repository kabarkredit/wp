=== Featured Image from URL | FIFU Premium ===
Requires at least: 5.3
Tested up to: 5.5
Requires PHP: 7.0
Stable tag: 4.8.7
