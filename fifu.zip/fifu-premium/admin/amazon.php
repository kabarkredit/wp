<?php

function fifu_amazon_search($keywords) {
    $ch = curl_init('https://www.amazon.es/s?k=' . $keywords . '&i=stripbooks');
    return fifu_curl($ch);
}

function fifu_amazon_first_result($html, $isbn) {
    preg_match('/<a class="a-link-normal s-no-outline" href="[^>]*keywords=' . $isbn . '[^>]*>/', $html, $tag);
    if (!$tag)
        return null;
    $href = fifu_get_attribute('href', $tag[0]);
    $ch = curl_init('https://www.amazon.es' . $href);
    return fifu_curl($ch);
}

function fifu_curl($ch) {
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:42.0) Gecko/20100101 Firefox/42.0');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_COOKIEFILE, '');
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
    return curl_exec($ch);
}

